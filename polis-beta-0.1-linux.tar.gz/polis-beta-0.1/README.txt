POLIS — Beta 0.1
================
Sic mundus creatus est.

HOW TO RUN
  ./run.sh

  If it does not start:
    chmod +x run.sh polis
    ./polis   (if SDL2 is installed system-wide)

CONTROLS
  See F1 in game.

WHAT TO TEST
  - Does it run on your system
  - Does audio work (menu AUDIO)
  - 1 player vs 3 AI
  - 2 players on one keyboard
  - Save / Load
  - General balance and feel

BUG REPORTS
  If the game crashes, a file polis_log_*.txt
  will appear in the game folder.
  Send it with a description of what happened.

JAK URUCHOMIC
  ./run.sh

  Jesli nie startuje:
    chmod +x run.sh polis

CO TESTOWAC
  - Czy dziala na twoim systemie
  - Czy dzwiek dziala (menu AUDIO)
  - 1 gracz vs 3 AI
  - 2 graczy na jednej klawiaturze
  - Zapis / Wczytanie
  - Ogolny balans i odczucia

BLEDY
  Jesli gra sie zawiesi, w folderze pojawi sie
  plik polis_log_*.txt. Przeslij go z opisem.

Beta 0.1 — May 2026 — Linux x86_64

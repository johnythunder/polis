POLIS — Beta 0.1
================
Sic mundus creatus est.

HOW TO RUN
  Double-click polis.exe
  or run from command line: polis.exe

REQUIREMENTS
  Windows 7 / 10 / 11 (x86_64)
  SDL2.dll must be in the same folder as polis.exe (included)

CONTROLS
  See F1 in game.

WHAT TO TEST
  - Does it run on your system
  - Does audio work (menu AUDIO)
  - 1 player vs 3 AI
  - 2 players on one keyboard
  - Save / Load
  - General balance and feel

BUG REPORTS
  If the game crashes, a file polis_log_*.txt
  will appear in the game folder.
  Send it with a description of what happened.
  Email: potapenko.iv@gmail.com
  Subject: [POLIS BETA]

JAK URUCHOMIC
  Kliknij dwukrotnie polis.exe
  SDL2.dll musi byc w tym samym folderze (jest dolaczona)

BLEDY
  Jesli gra sie zawiesi, pojawi sie plik polis_log_*.txt
  Przeslij go z opisem na: potapenko.iv@gmail.com
  Temat: [POLIS BETA]

Beta 0.1 — May 2026 — Windows x86_64
